const formulaire = document.querySelector("form");

formulaire.addEventListener("submit", function(event) {
    event.preventDefault();

    alert("Merci ! Votre message a bien été envoyé.");
});